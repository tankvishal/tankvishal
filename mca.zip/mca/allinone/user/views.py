from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,"user/index.html")

def tc(request):
    return render(request,"user/terms-conditions.html")

def about(request):
    return render(request,"user/about-us.html")

def contect(request):
    return render(request,"user/contect-us.html")

def registert(request):
    return render(request,"user/register-type.html")

def login(request):
    return render(request,"user/login.html")

def register(request):
    return render(request,"user/register.html")

def forgetpass(request):
    return render(request,"user/forget-password.html")
